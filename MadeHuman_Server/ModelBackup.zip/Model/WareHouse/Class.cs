﻿namespace MadeHuman_Server.Model.WareHouse
{
    public class Class
    {
    }
}
