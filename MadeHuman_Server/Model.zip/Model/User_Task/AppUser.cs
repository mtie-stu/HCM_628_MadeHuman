﻿using MadeHuman_Server.Model.Shop;
using Microsoft.AspNetCore.Identity;
using System.Text.Json.Serialization;

namespace MadeHuman_Server.Model.User_Task
{
    public class AppUser : IdentityUser
    {
        public enum UserType
        {
            Warehouse,
            Customer
        }
        public enum UserStatus
        {
            InActive,
            Active,
            Banned

        }

        public string? Name { get; set; }
        public string? Image { get; set; }
        [JsonIgnore] // 👈 Rất quan trọng để tránh vòng lặp khi serialize
        public ICollection<ShopOrder> ShopOrders { get; set; }
        public UserType UserTypes { get; set; }
        public UserStatus Status { get; set; }


    }
}
